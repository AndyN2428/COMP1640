<?php 
$conn = new mysqli('localhost', 'root', '', 'sms_db') or die("Could not connect to MySQL: " . mysqli_connect_error());

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $id = mysqli_real_escape_string($conn, $id);

    $sql = "SELECT name, type, size, path FROM upload WHERE id = '$id'";
    $res = $conn->query($sql);

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $name = $row['name'];
        $size = $row['size'];
        $type = $row['type'];
        $path = $row['path'];

        // Send headers
        header("Content-Disposition: attachment; filename=$name");
        header("Content-length: $size");
        header("Content-type: $type");

        // Adjust file path
        $path =  ltrim('/'.$path, '/'); 
        
        // Read and output the file
        readfile($path);

        // Exit after file output
        exit;
    } else {
        echo "File not found.";
        exit;
    }
}
?>

