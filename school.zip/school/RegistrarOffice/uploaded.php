<?php 
session_start();
include('../DB_connection.php'); 

if (isset($_SESSION['r_user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'Registrar Office') {
    if ($_SESSION['role'] == 'Registrar Office') {
        include "data/student.php";
        include "data/subject.php";
        include "data/grade.php";
        include "data/section.php";
    }
   if(isset($_GET['del'])){ 
      $id = intval($_GET['del']);
      $sq = "DELETE FROM `upload` WHERE `id` = '$id' ";
      $re = $conn->query($sq); 
      echo' <script> window.location.href = "uploaded.php"; </script>';
   };
                  ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registrar Office - Home</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="icon" href="../logo.png">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/07d0bc925d.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .fa-file-zipper {
                font-size: 30px;
                margin-bottom: 12px;
                margin-top: 5px;
            }
        </style>
    </head>
    <body>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <?php
                    // Pagination settings
                    $items_per_page = 5; // Number of items per page
                    $page = isset($_GET['page']) ? intval($_GET['page']) : 1; // Current page number
                    $offset = ($page - 1) * $items_per_page;

                    // Query total number of records
                    $total_records_sql = "SELECT COUNT(*) FROM `upload`";
                    $total_records_result = $conn->query($total_records_sql);
                    $total_records = $total_records_result->fetchColumn();
                    $total_pages = ceil($total_records / $items_per_page);

                    // Fetch records for the current page
                    $sql = "SELECT id, name, time FROM upload LIMIT $offset, $items_per_page";
                    $res = $conn->query($sql);
                    $i = 1;
                    if ($res && $res->rowCount() > 0) {
                        echo '<h2 style="text-transform:uppercase;font-size:50px;font-family:monospace;text-align:center;">Assigment</h2>';
                        while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
                        
                            $id = $row['id'];
                            $name = $row['name'];
                            $time = $row['time'];
                            ?>
                            <div class="down"
                                 style="width:1000px;margin:0 auto;position:relative;top:20px;margin-bottom:50px;">
                                <a href="download.php?id=<?php echo $id; ?>">
                                    <stt>#<?= $i ?></stt>
                                    <span class="lbl">Download</span> | <span class="data"><?php echo $name ?></span>
                                    <small style="float:right;color:black;"><?= $time ?></small>
                                    <?php
                            
                                        echo "<a href='uploaded.php?q=7&del=$id' style='margin-left:50px;'><i class='fa fa-trash'></i>Delete</a> ";
                                    
                                    ?>
                                    <hr>
                                </a>
                            </div>
                            <?php  $i++;
                        }
                        // Pagination links
                        echo '<div style="text-align: center;">';
                        for ($i = 1; $i <= $total_pages; $i++) {
                            echo '<a href="?page=' . $i . '">' . $i . '</a> ';
                        }
                        echo '</div>';
                    } else {
                        echo "No records found.";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function () {
            $("#navLinks li:nth-child(1) a").addClass('active');
        });
    </script>

    </body>
    </html>
    <?php
}
?>
