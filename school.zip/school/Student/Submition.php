<?php 
session_start();

if (isset($_SESSION['student_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Student') {
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <script src="sweetalert2.all.min.js"></script>
    <script src="sweetalert2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<link rel="stylesheet" href="sweetalert2.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Student - Submition</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="icon" href="../logo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
        include "inc/navbar.php";
        include "../DB_connection.php";

     ?>
    <?php 
  if(isset($_POST['btn']) && $_FILES['fname']['size'] > 0) {
    // Retrieve file details
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $fileName = $_FILES['fname']['name'];
    $tmpName = $_FILES['fname']['tmp_name'];
    $fileSize = $_FILES['fname']['size'];
    $fileType = $_FILES['fname']['type'];
    $status = 'choduyet';
$time = date('H:i:s / d-m-Y');
    // Directory to upload files
    $uploadDir = 'C:/xampp/htdocs/school/studyMaterial/';
    $filePath = $uploadDir . $fileName;

    // Move the uploaded file to the specified directory
    $result = move_uploaded_file($tmpName, $filePath);
    if (!$result) {
        echo "Error uploading file";
        exit;
    }

 
    // Prepare and execute SQL query to insert file details into the database
    $sql = "INSERT INTO upload (name, size, type, path, status, time) VALUES ('$fileName', '$fileSize', '$fileType', '$filePath', '$status', '$time')";
    $result = $conn->exec($sql);
    if($result !== false && $result > 0) {
        echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            tb();
        });
    
        function tb(){
            Swal.fire({
                title: "Thành công",
                text: "Bạn đã nộp tài liệu",
                icon: "success"
            });
        }
        </script>';
    } else {
        echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            tb();
        });
    
        function tb(){
            Swal.fire({
                title: "Thất bại",
                text: "Something went wrong!",
                icon: "error"
            });
        }
        </script>';
    }
    
}


?>

<form method="POST" enctype="multipart/form-data">
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h3 style="margin-top: 5%;">Add Submition  <small></small></h3> 
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form role="form">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label>Choose file that you want to upload</label>
                                                    <input type="file" name="fname" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <button type="submit" class="btn btn-success" name="btn">Upload</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
                                        </div>
                                        <!-- /.col-lg-6 (nested) -->
                                    </div>
                                    <!-- /.row (nested) -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
                                 
  



    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></>	
   <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(4) a").addClass('active');
        });

     
      
    </script>
</body>
</html>
<?php 

  }else {
    header("Location: ../login.php");
    exit;
  } 
}else {
	header("Location: ../login.php");
	exit;
} 

?>